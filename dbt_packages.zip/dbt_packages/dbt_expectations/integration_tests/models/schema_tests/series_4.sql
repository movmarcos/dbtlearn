{{ dbt_date.generate_series(upper_bound=4) }}
